package Calender;

public class Calender {
	
	private Meeting[] meetings;

	public Meeting[] getMeetings() {
		return meetings;
	}

	public void setMeetings(Meeting[] meetings) {
		this.meetings = meetings;
	}
	
	

}
